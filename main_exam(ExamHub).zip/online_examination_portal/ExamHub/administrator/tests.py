from django.test import TestCase

# Create your tests here.
# Example:
# from .models import Technology
#
# class TechnologyModelTest(TestCase):
#     def test_technology_creation(self):
#         technology = Technology.objects.create(name="Python", description="Programming language")
#         self.assertEqual(technology.name, "Python")
#         self.assertEqual(technology.description, "Programming language")
#         self.assertTrue(Technology.objects.filter(name="Python").exists())